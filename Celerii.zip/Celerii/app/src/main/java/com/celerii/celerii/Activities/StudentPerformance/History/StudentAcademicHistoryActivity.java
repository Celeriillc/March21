package com.celerii.celerii.Activities.StudentPerformance.History;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.celerii.celerii.R;
import com.celerii.celerii.adapters.StudentAcademicHistoryAdapter;
import com.celerii.celerii.helperClasses.Analytics;
import com.celerii.celerii.helperClasses.CheckNetworkConnectivity;
import com.celerii.celerii.helperClasses.Date;
import com.celerii.celerii.helperClasses.SharedPreferencesManager;
import com.celerii.celerii.helperClasses.Term;
import com.celerii.celerii.models.AcademicRecord;
import com.celerii.celerii.models.AcademicRecordStudent;
import com.celerii.celerii.models.Class;
import com.celerii.celerii.models.Student;
import com.celerii.celerii.models.StudentAcademicHistoryRowModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class StudentAcademicHistoryActivity extends AppCompatActivity {

    SharedPreferencesManager sharedPreferencesManager;

    FirebaseAuth auth;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mDatabaseReference;
    FirebaseUser mFirebaseUser;

    SwipeRefreshLayout mySwipeRefreshLayout;
    RelativeLayout errorLayout, progressLayout;
    TextView errorLayoutText;

    Toolbar toolbar;
    private ArrayList<StudentAcademicHistoryRowModel> studentAcademicHistoryRowModelList;
    public RecyclerView recyclerView;
    public StudentAcademicHistoryAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    String activeClass = "";
    String year, term, year_term;

    String featureUseKey = "";
    String featureName = "Class Academic Records";
    long sessionStartTime = 0;
    String sessionDurationInSeconds = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_academic_history);

        sharedPreferencesManager = new SharedPreferencesManager(this);

        mySwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swiperefresh);
        toolbar = (Toolbar) findViewById(R.id.hometoolbar);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        errorLayout = (RelativeLayout) findViewById(R.id.errorlayout);
        errorLayoutText = (TextView) errorLayout.findViewById(R.id.errorlayouttext);
        progressLayout = (RelativeLayout) findViewById(R.id.progresslayout);

        activeClass = sharedPreferencesManager.getActiveClass();

        if (activeClass == null) {
            Gson gson = new Gson();
            ArrayList<Class> myClasses = new ArrayList<>();
            String myClassesJSON = sharedPreferencesManager.getMyClasses();
            Type type = new TypeToken<ArrayList<Class>>() {}.getType();
            myClasses = gson.fromJson(myClassesJSON, type);

            if (myClasses != null) {
                gson = new Gson();
                activeClass = gson.toJson(myClasses.get(0));
                sharedPreferencesManager.setActiveClass(activeClass);
            } else {
                setSupportActionBar(toolbar);
                getSupportActionBar().setTitle("Class Academic Records"); //TODO: Use class name, make dynamic
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setHomeButtonEnabled(true);
                mySwipeRefreshLayout.setRefreshing(false);
                recyclerView.setVisibility(View.GONE);
                progressLayout.setVisibility(View.GONE);
                errorLayout.setVisibility(View.VISIBLE);
                errorLayoutText.setText(Html.fromHtml("You're not connected to any classes yet. Use the " + "<b>" + "Search" + "</b>" + " button to search for a school and request connection to their classes."));
                return;
            }
        }

        Gson gson = new Gson();
        Type type = new TypeToken<Class>() {}.getType();
        Class activeClassModel = gson.fromJson(activeClass, type);
        activeClass = activeClassModel.getID();

        auth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference();
        mFirebaseUser = auth.getCurrentUser();

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(activeClassModel.getClassName()); //TODO: Use class name, make dynamic
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        mLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mLayoutManager);
        errorLayout.setVisibility(View.GONE);

        recyclerView.setVisibility(View.GONE);
        progressLayout.setVisibility(View.VISIBLE);

        studentAcademicHistoryRowModelList = new ArrayList<>();
        loadNewDetailsFromFirebase();
        mAdapter = new StudentAcademicHistoryAdapter(studentAcademicHistoryRowModelList, this);
        recyclerView.setAdapter(mAdapter);

        mySwipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        loadNewDetailsFromFirebase();
                    }
                }
        );
    }

    HashMap<String, Double> studentScore = new HashMap<>();
    HashMap<String, Integer> studentCounter = new HashMap<>();
    int subjectCounter = 0;

    private void loadNewDetailsFromFirebase() {
        if (!CheckNetworkConnectivity.isNetworkAvailable(this)) {
            mySwipeRefreshLayout.setRefreshing(false);
            recyclerView.setVisibility(View.GONE);
            progressLayout.setVisibility(View.GONE);
            errorLayout.setVisibility(View.VISIBLE);
            errorLayoutText.setText("Your device is not connected to the internet. Check your connection and try again.");
            return;
        }

        year = Date.getYear();
        term = Term.getTermShort();
        year_term = year + "_" + term;

        Gson gson = new Gson();
        HashMap<String, HashMap<String, Student>> classStudentsForTeacherMap = new HashMap<String, HashMap<String, Student>>();
        String classStudentsForTeacherJSON = sharedPreferencesManager.getClassStudentForTeacher();
        Type type = new TypeToken<HashMap<String, HashMap<String, Student>>>() {}.getType();
        classStudentsForTeacherMap = gson.fromJson(classStudentsForTeacherJSON, type);

        if (classStudentsForTeacherMap == null || classStudentsForTeacherMap.size() == 0) {
            mySwipeRefreshLayout.setRefreshing(false);
            recyclerView.setVisibility(View.GONE);
            progressLayout.setVisibility(View.GONE);
            errorLayout.setVisibility(View.VISIBLE);
            errorLayoutText.setText("This class doesn't contain any students");
        } else {
            final HashMap<String, Student> classMap = classStudentsForTeacherMap.get(activeClass);

            studentScore = new HashMap<>();
            studentCounter = new HashMap<>();
            studentAcademicHistoryRowModelList.clear();

            for (final Map.Entry<String, Student> entry : classMap.entrySet()) {
                final String studentID = entry.getKey();
                Student studentModel = entry.getValue();

                final StudentAcademicHistoryRowModel studentAcademicHistoryRowModel = new StudentAcademicHistoryRowModel();
                studentAcademicHistoryRowModel.setImageURL(studentModel.getImageURL());
                studentAcademicHistoryRowModel.setName(studentModel.getFirstName() + " " + studentModel.getLastName());
                studentAcademicHistoryRowModel.setStudentID(studentID);
                studentAcademicHistoryRowModelList.add(studentAcademicHistoryRowModel);
//                studentScore.put(studentID, 0.0);
//                studentCounter.put(studentID, 0);

                mDatabaseReference = mFirebaseDatabase.getReference("AcademicRecordStudent").child(studentID);
                mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            final int childrenCount = (int) dataSnapshot.getChildrenCount();
                            subjectCounter = 0;
                            for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {

                                String subject_year_term = postSnapshot.getKey();
                                String yearTermKey = subject_year_term.split("_")[1] + "_" + subject_year_term.split("_")[2];

                                if (yearTermKey.equals(year_term)) {
                                    mDatabaseReference = mFirebaseDatabase.getReference("AcademicRecordStudent").child(entry.getKey()).child(subject_year_term);
                                    mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                            if (dataSnapshot.exists()) {
                                                Double termAverage = 0.0;
                                                String localStudentID = "";

                                                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                                    AcademicRecordStudent academicRecordStudent = postSnapshot.getValue(AcademicRecordStudent.class);
                                                    localStudentID = academicRecordStudent.getStudentID();
                                                    double testClassAverage = Double.valueOf(academicRecordStudent.getScore());
                                                    double maxObtainable = Double.valueOf(academicRecordStudent.getMaxObtainable());
                                                    double percentageOfTotal = Double.valueOf(academicRecordStudent.getPercentageOfTotal());

                                                    double normalizedTestClassAverage = (testClassAverage / maxObtainable) * percentageOfTotal;
                                                    termAverage += normalizedTestClassAverage;
                                                }

                                                if (!studentScore.containsKey(localStudentID)) {
                                                    studentScore.put(localStudentID, termAverage);
                                                } else {
                                                    studentScore.put(localStudentID, studentScore.get(localStudentID) + termAverage);
                                                }

                                                if (!studentCounter.containsKey(localStudentID)) {
                                                    studentCounter.put(localStudentID, 1);
                                                } else {
                                                    studentCounter.put(localStudentID, studentCounter.get(localStudentID) + 1);
                                                }
                                            }
                                            subjectCounter++;

                                            if (subjectCounter == childrenCount) {
                                                subjectCounter = 0;
                                            }

                                            if (studentCounter.size() == classMap.size()) {
                                                for (StudentAcademicHistoryRowModel studentAcademicHistoryRowModel: studentAcademicHistoryRowModelList) {
                                                    String key = studentAcademicHistoryRowModel.getStudentID();
                                                    try {
                                                        double score = (int) ((studentScore.get(key) / studentCounter.get(key)));
                                                        studentAcademicHistoryRowModel.setAverage(String.valueOf(score));
                                                    } catch (Exception e) {
                                                        studentAcademicHistoryRowModel.setAverage(String.valueOf(0.0));
                                                    }
                                                }

                                                mAdapter.notifyDataSetChanged();
                                                mySwipeRefreshLayout.setRefreshing(false);
                                                progressLayout.setVisibility(View.GONE);
                                                errorLayout.setVisibility(View.GONE);
                                                recyclerView.setVisibility(View.VISIBLE);

                                            }
                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {

                                        }
                                    });
                                } else {
                                    subjectCounter++;
                                }
                            }
                        } else {
                            studentScore.put(studentID, 0.0);
                            studentCounter.put(studentID, 1);

                            if (studentCounter.size() == classMap.size()) {
                                for (StudentAcademicHistoryRowModel studentAcademicHistoryRowModel: studentAcademicHistoryRowModelList) {
                                    String key = studentAcademicHistoryRowModel.getStudentID();
                                    try {
                                        double score = (int) ((studentScore.get(key) / studentCounter.get(key)));
                                        studentAcademicHistoryRowModel.setAverage(String.valueOf(score));
                                    } catch (Exception e) {
                                        studentAcademicHistoryRowModel.setAverage(String.valueOf(0.0));
                                    }
                                }

                                mAdapter.notifyDataSetChanged();
                                mySwipeRefreshLayout.setRefreshing(false);
                                progressLayout.setVisibility(View.GONE);
                                errorLayout.setVisibility(View.GONE);
                                recyclerView.setVisibility(View.VISIBLE);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        }
    }

//    int studentCounter = 0;
//    private void loadNeDetailsFromFirebase() {
//        if (!CheckNetworkConnectivity.isNetworkAvailable(this)) {
//            mySwipeRefreshLayout.setRefreshing(false);
//            recyclerView.setVisibility(View.GONE);
//            progressLayout.setVisibility(View.GONE);
//            errorLayout.setVisibility(View.VISIBLE);
//            errorLayoutText.setText("Your device is not connected to the internet. Check your connection and try again.");
//            return;
//        }
//
//        year = Date.getYear();
//        term = Term.getTermShort();
//        year_term = year + "_" + term;
//
//        Gson gson = new Gson();
//        HashMap<String, HashMap<String, Student>> classStudentsForTeacherMap = new HashMap<String, HashMap<String, Student>>();
//        String classStudentsForTeacherJSON = sharedPreferencesManager.getClassStudentForTeacher();
//        Type type = new TypeToken<HashMap<String, HashMap<String, Student>>>() {}.getType();
//        classStudentsForTeacherMap = gson.fromJson(classStudentsForTeacherJSON, type);
//
//        if (classStudentsForTeacherMap == null || classStudentsForTeacherMap.size() == 0) {
//            mySwipeRefreshLayout.setRefreshing(false);
//            recyclerView.setVisibility(View.GONE);
//            progressLayout.setVisibility(View.GONE);
//            errorLayout.setVisibility(View.VISIBLE);
//            errorLayoutText.setText("This class doesn't contain any students");
//        } else {
//            HashMap<String, Student> classMap = classStudentsForTeacherMap.get(activeClass);
//            final int studentCount = classMap.size();
//            for (Map.Entry<String, Student> entry : classMap.entrySet()) {
//                final String studentID = entry.getKey();
//                Student studentModel = entry.getValue();
//
//                final StudentAcademicHistoryRowModel studentAcademicHistoryRowModel = new StudentAcademicHistoryRowModel();
//                studentAcademicHistoryRowModel.setImageURL(studentModel.getImageURL());
//                studentAcademicHistoryRowModel.setName(studentModel.getFirstName() + " " + studentModel.getLastName());
//                studentAcademicHistoryRowModel.setStudentID(studentID);
//
//                mDatabaseReference = mFirebaseDatabase.getReference("AcademicRecordStudent-Subject").child(studentID);
//                mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        if (dataSnapshot.exists()) {
//                            final int numberOfSubjects = (int) dataSnapshot.getChildrenCount();
//                            for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {
//                                String term = Term.getTermShort();
//                                String year = Date.getYear();
//                                String subject_year_term = postSnapshot.getKey() + "_" + year + "_" + term;
//
//                                mDatabaseReference = mFirebaseDatabase.getReference("AcademicRecordStudent").child(studentID).child(subject_year_term);
//                                mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//                                    @Override
//                                    public void onDataChange(DataSnapshot dataSnapshot) {
//                                        studentCounter++;
//                                        studentScoreCount++;
//                                        if (dataSnapshot.exists()) {
//                                            double termScore = 0.0;
//                                            for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {
//                                                AcademicRecordStudent academicRecordStudent = postSnapshot.getValue(AcademicRecordStudent.class);
//                                                double testScore = Double.valueOf(academicRecordStudent.getClassAverage());
//                                                double maxObtainable = Double.valueOf(academicRecordStudent.getMaxObtainable());
//                                                double percentageOfTotal = Double.valueOf(academicRecordStudent.getPercentageOfTotal());
//                                                double normalizedTestClassAverage = (testScore / maxObtainable) * percentageOfTotal;
//                                                termScore += normalizedTestClassAverage;
//                                            }
//                                            studentTotalScore += termScore;
//
//                                            if (numberOfSubjects == studentScoreCount) {
//                                                studentAverageScore = studentTotalScore / studentScoreCount;
//                                                studentAcademicHistoryRowModel.setAverage(String.valueOf(studentAverageScore));
//                                                studentAcademicHistoryRowModelList.add(studentAcademicHistoryRowModel);
//
//                                                if (studentCount == studentCounter) {
//                                                    mySwipeRefreshLayout.setRefreshing(false);
//                                                    progressLayout.setVisibility(View.GONE);
//                                                    errorLayout.setVisibility(View.GONE);
//                                                    recyclerView.setVisibility(View.VISIBLE);
//                                                }
//                                            }
//                                        } else {
//                                            if (studentCount == studentCounter) {
//                                                mySwipeRefreshLayout.setRefreshing(false);
//                                                progressLayout.setVisibility(View.GONE);
//                                                errorLayout.setVisibility(View.GONE);
//                                                recyclerView.setVisibility(View.VISIBLE);
//                                            }
//                                        }
//                                    }
//
//                                    @Override
//                                    public void onCancelled(DatabaseError databaseError) {
//
//                                    }
//                                });
//                            }
//                        } else {
//                            studentCounter++;
//                            studentAcademicHistoryRowModel.setAverage(String.valueOf(0.0));
//                            studentAcademicHistoryRowModelList.add(studentAcademicHistoryRowModel);
//
//                            if (studentCount == studentCounter) {
//                                mySwipeRefreshLayout.setRefreshing(false);
//                                progressLayout.setVisibility(View.GONE);
//                                errorLayout.setVisibility(View.GONE);
//                                recyclerView.setVisibility(View.VISIBLE);
//                            }
//                        }
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//
//                    }
//                });
//            }
//        }
//    }

    private void loadDetailsFromFirebase() {
        if (!CheckNetworkConnectivity.isNetworkAvailable(this)) {
            mySwipeRefreshLayout.setRefreshing(false);
            recyclerView.setVisibility(View.GONE);
            progressLayout.setVisibility(View.GONE);
            errorLayout.setVisibility(View.VISIBLE);
            errorLayoutText.setText("Your device is not connected to the internet. Check your connection and try again.");
            return;
        }

        mDatabaseReference = mFirebaseDatabase.getReference("Class Students/" + activeClass);
        mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    final int childrenCount = (int) dataSnapshot.getChildrenCount();
                    studentAcademicHistoryRowModelList.clear();
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                        final String childKey = postSnapshot.getKey();
                        mDatabaseReference = mFirebaseDatabase.getReference("Student").child(childKey);
                        mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                Student child = dataSnapshot.getValue(Student.class);
                                final StudentAcademicHistoryRowModel studentAcademicHistoryRowModel = new StudentAcademicHistoryRowModel();
                                studentAcademicHistoryRowModel.setImageURL(child.getImageURL());
                                studentAcademicHistoryRowModel.setName(child.getFirstName() + " " + child.getLastName());
                                studentAcademicHistoryRowModel.setStudentID(childKey);

                                final String year = Date.getYear();

                                mDatabaseReference = mFirebaseDatabase.getReference("AcademicRecordTotal/AcademicRecordStudent").child(childKey);
                                mDatabaseReference.orderByChild("academicYear").equalTo(year).addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        double score = 0;
                                        if (dataSnapshot.exists()) {
                                            double summer = 0;
                                            double counter = 0;
                                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                                AcademicRecordStudent academicRecordStudent = postSnapshot.getValue(AcademicRecordStudent.class);
                                                summer = summer + Double.valueOf(academicRecordStudent.getScore());
                                                counter++;
                                            }
                                            score = (summer / counter);
                                        }
                                        studentAcademicHistoryRowModel.setAverage(String.valueOf(score));
                                        studentAcademicHistoryRowModelList.add(studentAcademicHistoryRowModel);
                                        mAdapter.notifyDataSetChanged();

                                        if (childrenCount == studentAcademicHistoryRowModelList.size()) {
                                            mySwipeRefreshLayout.setRefreshing(false);
                                            progressLayout.setVisibility(View.GONE);
                                            errorLayout.setVisibility(View.GONE);
                                            recyclerView.setVisibility(View.VISIBLE);
                                        }
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });
                    }
                } else {
                    mySwipeRefreshLayout.setRefreshing(false);
                    recyclerView.setVisibility(View.GONE);
                    progressLayout.setVisibility(View.GONE);
                    errorLayout.setVisibility(View.VISIBLE);
                    errorLayoutText.setText("This class doesn't contain any students");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (sharedPreferencesManager.getActiveAccount().equals("Parent")) {
            featureUseKey = Analytics.featureAnalytics("Parent", mFirebaseUser.getUid(), featureName);
        } else {
            featureUseKey = Analytics.featureAnalytics("Teacher", mFirebaseUser.getUid(), featureName);
        }
        sessionStartTime = System.currentTimeMillis();
    }

    @Override
    protected void onStop() {
        super.onStop();

        sessionDurationInSeconds = String.valueOf((System.currentTimeMillis() - sessionStartTime) / 1000);
        String day = Date.getDay();
        String month = Date.getMonth();
        String year = Date.getYear();
        String day_month_year = day + "_" + month + "_" + year;
        String month_year = month + "_" + year;

        HashMap<String, Object> featureUseUpdateMap = new HashMap<>();
        String mFirebaseUserID = mFirebaseUser.getUid();

        featureUseUpdateMap.put("Analytics/Feature Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Daily Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + day_month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Monthly Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Yearly Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);

        featureUseUpdateMap.put("Analytics/Feature Use Analytics/" + featureName + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Daily Use Analytics/" + featureName + "/" + day_month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Monthly Use Analytics/" + featureName + "/" + month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Yearly Use Analytics/" + featureName + "/" + year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);

        DatabaseReference featureUseUpdateRef = FirebaseDatabase.getInstance().getReference();
        featureUseUpdateRef.updateChildren(featureUseUpdateMap);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
