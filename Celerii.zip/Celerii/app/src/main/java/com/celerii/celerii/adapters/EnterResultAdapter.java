package com.celerii.celerii.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.celerii.celerii.Activities.EditTermAndYearInfo.EnterResultsEditExamTypeActivity;
import com.celerii.celerii.Activities.EditTermAndYearInfo.EnterResultsEditMaxObtainableActivity;
import com.celerii.celerii.Activities.EditTermAndYearInfo.EnterResultsEditPercentageOfTotalScoreActivity;
import com.celerii.celerii.Activities.EditTermAndYearInfo.EnterResultsEditSubjectsActivity;
import com.celerii.celerii.Activities.EditTermAndYearInfo.EnterResultsEditTermActivity;
import com.celerii.celerii.Activities.StudentPerformance.EnterResultsActivity;
import com.celerii.celerii.R;
import com.celerii.celerii.helperClasses.CustomToast;
import com.celerii.celerii.helperClasses.Date;
import com.celerii.celerii.helperClasses.Term;
import com.celerii.celerii.models.EnterResultHeader;
import com.celerii.celerii.models.EnterResultRow;
import com.bumptech.glide.Glide;
import com.codetroopers.betterpickers.calendardatepicker.CalendarDatePickerDialogFragment;

import java.util.List;

import jp.wasabeef.glide.transformations.CropCircleTransformation;

/**
 * Created by DELL on 8/18/2017.
 */

public class EnterResultAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<EnterResultRow> enterResultRowList;
    private Context context;
    private EnterResultHeader enterResultHeader;
    private Activity myActivity;
    public static final int Header = 1;
    public static final int Normal = 2;
    public static final int Footer = 3;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView studentName;
        public EditText score;
        public ImageView studentPic;
        public View clickableView;

        public MyViewHolder(final View view) {
            super(view);
            studentName = (TextView) view.findViewById(R.id.kidname);
            score = (EditText) view.findViewById(R.id.kidscore);
            studentPic = (ImageView) view.findViewById(R.id.kidPicture);
            clickableView = view;
        }
    }

    public class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView teacher, className, subject, term, date, maximumScore, percentageOfTotal, testType;
        LinearLayout teacherLayout, classNameLayout, subjectLayout, termLayout, dateLayout, maximumScoreLayout, percentageOfTotalLayout,
                testTypeLayout;

        public HeaderViewHolder(View view) {
            super(view);
            teacher = (TextView) view.findViewById(R.id.teacher);
            className = (TextView) view.findViewById(R.id.classname);
            subject = (TextView) view.findViewById(R.id.subject);
            term = (TextView) view.findViewById(R.id.term);
            date = (TextView) view.findViewById(R.id.date);
            maximumScore = (TextView) view.findViewById(R.id.maximumscore);
            percentageOfTotal = (TextView) view.findViewById(R.id.percentageoftotal);
            testType = (TextView) view.findViewById(R.id.testtype);

            teacherLayout = (LinearLayout) view.findViewById(R.id.teacherlayout);
            classNameLayout = (LinearLayout) view.findViewById(R.id.classlayout);
            subjectLayout = (LinearLayout) view.findViewById(R.id.subjectlayout);
            termLayout = (LinearLayout) view.findViewById(R.id.termlayout);
            dateLayout = (LinearLayout) view.findViewById(R.id.datelayout);
            maximumScoreLayout = (LinearLayout) view.findViewById(R.id.maximumscorelayout);
            percentageOfTotalLayout = (LinearLayout) view.findViewById(R.id.percentageoftotallayout);
            testTypeLayout = (LinearLayout) view.findViewById(R.id.testtypelayout);
        }
    }

    public class FooterViewHolder extends RecyclerView.ViewHolder {
        Button saveToCloud;

        public FooterViewHolder(View view) {
            super(view);
            saveToCloud = (Button) view.findViewById(R.id.savetocloud);
        }
    }

    public EnterResultAdapter(List<EnterResultRow> enterResultRowList, EnterResultHeader enterResultHeader, Activity myActivity,
                                           Context context) {
        this.enterResultRowList = enterResultRowList;
        this.enterResultHeader = enterResultHeader;
        this.myActivity = myActivity;
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View rowView;
        switch (viewType) {
            case Normal:
                rowView = LayoutInflater.from(parent.getContext()).inflate(R.layout.enter_result_row, parent, false);
                return new EnterResultAdapter.MyViewHolder(rowView);
            case Header:
                rowView = LayoutInflater.from(parent.getContext()).inflate(R.layout.enter_result_header, parent, false);
                return new EnterResultAdapter.HeaderViewHolder(rowView);
            case Footer:
                rowView = LayoutInflater.from(parent.getContext()).inflate(R.layout.enter_result_footer, parent, false);
                return new EnterResultAdapter.FooterViewHolder(rowView);
            default:
                rowView = LayoutInflater.from(parent.getContext()).inflate(R.layout.enter_result_row, parent, false);
                return new EnterResultAdapter.MyViewHolder(rowView);
        }
    }

    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        if(holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).teacher.setText(enterResultHeader.getTeacher());
            ((HeaderViewHolder) holder).className.setText(enterResultHeader.getClassName());
            ((HeaderViewHolder) holder).subject.setText(enterResultHeader.getSubject());
            ((HeaderViewHolder) holder).testType.setText(enterResultHeader.getTestType());
            ((HeaderViewHolder) holder).maximumScore.setText(enterResultHeader.getMaxScore());
            ((HeaderViewHolder) holder).percentageOfTotal.setText(enterResultHeader.getPercentageOfTotal() + "%");
            ((HeaderViewHolder) holder).date.setText(Date.DateFormatMMDDYYYY(enterResultHeader.getDate()));
            ((HeaderViewHolder) holder).term.setText(Term.Term(enterResultHeader.getTerm()));

            ((HeaderViewHolder) holder).subjectLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, EnterResultsEditSubjectsActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("Active Class", enterResultHeader.getClassID());
                    bundle.putString("Subject", enterResultHeader.getSubject());
                    bundle.putString("Activity", "WriteResult");
                    intent.putExtras(bundle);
                    myActivity.startActivityForResult(intent, 1);
                }
            });

            ((HeaderViewHolder) holder).testTypeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, EnterResultsEditExamTypeActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("Test Type", enterResultHeader.getTestType());
                    intent.putExtras(bundle);
                    myActivity.startActivityForResult(intent, 2);
                }
            });

            ((HeaderViewHolder) holder).maximumScoreLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, EnterResultsEditMaxObtainableActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("Maximum Obtainable", enterResultHeader.getMaxScore());
                    intent.putExtras(bundle);
                    myActivity.startActivityForResult(intent, 3);
                }
            });

            ((HeaderViewHolder) holder).percentageOfTotalLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, EnterResultsEditPercentageOfTotalScoreActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putDouble("PreviousPercentageOfTotal", enterResultHeader.getPreviousPercentageOfTotal());
                    bundle.putString("PercentageOfTotal", enterResultHeader.getPercentageOfTotal());
                    String subject_year_term = enterResultHeader.getSubject() + "_" + enterResultHeader.getYear() + "_" + enterResultHeader.getTerm();
                    String class_subject_year_term = enterResultHeader.getClassID() + "_" + enterResultHeader.getSubject() + "_" + enterResultHeader.getYear() + "_" + enterResultHeader.getTerm();
                    bundle.putString("SubjectYearTerm", subject_year_term);
                    bundle.putString("ClassSubjectYearTerm", class_subject_year_term);
                    bundle.putString("ClassID", enterResultHeader.getClassID());
                    intent.putExtras(bundle);
                    myActivity.startActivityForResult(intent, 4);
                }
            });

            ((HeaderViewHolder) holder).dateLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CalendarDatePickerDialogFragment cdp = new CalendarDatePickerDialogFragment().setThemeCustom(R.style.MyCustomBetterPickersDialogs);
                    cdp.show(((EnterResultsActivity)context).getSupportFragmentManager(), "Material Calendar Example");

                    cdp.setOnDateSetListener(new CalendarDatePickerDialogFragment.OnDateSetListener() {
                        @Override
                        public void onDateSet(CalendarDatePickerDialogFragment dialog, int year, int monthOfYear, int dayOfMonth) {
                            Intent informationIntent = new Intent("Date Information");
                            informationIntent.putExtra("Year", String.valueOf(year));
                            informationIntent.putExtra("Month", String.valueOf(monthOfYear + 1));
                            informationIntent.putExtra("Day", String.valueOf(dayOfMonth));
                            LocalBroadcastManager.getInstance(context).sendBroadcast(informationIntent);
                        }
                    });
                }
            });

            ((HeaderViewHolder) holder).termLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, EnterResultsEditTermActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("Term", enterResultHeader.getTerm());
                    intent.putExtras(bundle);
                    myActivity.startActivityForResult(intent, 5);
                }
            });
        } else if(holder instanceof FooterViewHolder) {
            ((FooterViewHolder) holder).saveToCloud.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (context instanceof EnterResultsActivity) {
                        ((EnterResultsActivity)context).saveNewToCloud();
                    }
                }
            });
        } else {
            final EnterResultRow enterResultRow = enterResultRowList.get(position);

            ((MyViewHolder)holder).studentName.setText(enterResultRow.getName());

            Glide.with(context)
                    .load(enterResultRow.getImageURL())
                    .crossFade()
                    .placeholder(R.drawable.profileimageplaceholder)
                    .error(R.drawable.profileimageplaceholder)
                    .centerCrop().bitmapTransform(new CropCircleTransformation(context))
                    .into(((MyViewHolder)holder).studentPic);

            ((MyViewHolder)holder).clickableView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        ((MyViewHolder) holder).score.setEnabled(true);
                        ((MyViewHolder) holder).score.requestFocus();

                        //Show keyboard by default
                        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
                    } catch (Exception e) {

                    }
                }
            });

            ((MyViewHolder) holder).score.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
//                    String score = ((MyViewHolder) holder).score.getText().toString();
//                    if (score.equals("")){
//                        score = "0";
//                    }
//                    enterResultRow.setScore(score);
                }

                @Override
                public void afterTextChanged(Editable s) {
                    String score = ((MyViewHolder) holder).score.getText().toString();
                    if (score.equals("")){
                        score = "0";
                    }
                    if (Double.valueOf(score) > Double.valueOf(enterResultHeader.getMaxScore())) {
                        ((MyViewHolder) holder).score.setText("0");
                        CustomToast.blueBackgroundToast(context, "Error: The entered score is greater than the max obtainable");
                    }
//                    else {
//                        enterResultRowList.get(position).setScore(score);
//                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return enterResultRowList.size();
    }

    @Override
    public int getItemViewType(int position) {

        if(isPositionHeader (position)) {
            return Header;
        } else if(isPositionFooter (position)) {
            return Footer;
        }
        return Normal;
    }

    private boolean isPositionHeader (int position) {
        return position == 0;
    }

    private boolean isPositionFooter (int position) {
        return position == enterResultRowList.size () - 1;
    }
}
