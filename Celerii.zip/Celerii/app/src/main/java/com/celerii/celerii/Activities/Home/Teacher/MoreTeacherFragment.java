package com.celerii.celerii.Activities.Home.Teacher;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.celerii.celerii.Activities.EditProfiles.EditTeacherProfileActivity;
import com.celerii.celerii.Activities.Events.EventsRowActivity;
import com.celerii.celerii.Activities.Intro.IntroSlider;
import com.celerii.celerii.Activities.Newsletters.NewsletterRowActivity;
import com.celerii.celerii.Activities.Profiles.ClassProfileActivity;
import com.celerii.celerii.Activities.Profiles.TeacherProfileOneActivity;
import com.celerii.celerii.Activities.Settings.SettingsActivityTeacher;
import com.celerii.celerii.Activities.StudentAttendance.TeacherAttendanceActivity;
import com.celerii.celerii.Activities.StudentAttendance.TeacherTakeAttendanceActivity;
import com.celerii.celerii.Activities.StudentPerformance.EnterResultsActivity;
import com.celerii.celerii.Activities.StudentPerformance.History.StudentAcademicHistoryActivity;
import com.celerii.celerii.Activities.TeacherPerformance.TeacherPerformanceRowActivity;
import com.celerii.celerii.Activities.Timetable.TeacherTimetableActivity;
import com.celerii.celerii.Activities.Utility.SwitchActivityTeacherParent;
import com.celerii.celerii.R;
import com.celerii.celerii.adapters.MoreTeacherAdapter;
import com.celerii.celerii.helperClasses.Analytics;
import com.celerii.celerii.helperClasses.Date;
import com.celerii.celerii.helperClasses.LogoutProtocol;
import com.celerii.celerii.helperClasses.SharedPreferencesManager;
import com.celerii.celerii.helperClasses.UpdateDataFromFirebase;
import com.celerii.celerii.models.Class;
import com.celerii.celerii.models.MoreTeacherHeaderModel;
import com.celerii.celerii.models.MoreTeachersModel;
import com.celerii.celerii.models.Student;
import com.celerii.celerii.models.Teacher;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import jp.wasabeef.glide.transformations.CropCircleTransformation;


/**
 * A simple {@link Fragment} subclass.
 */
public class MoreTeacherFragment extends Fragment {
    Context context;

    FirebaseAuth mAuth;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mDatabaseReference;
    FirebaseUser mFirebaseUser;

    private ArrayList<Class> moreTeachersModelList;
    private MoreTeacherHeaderModel moreHeader;
    public RecyclerView recyclerView;
    public MoreTeacherAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    SharedPreferencesManager sharedPreferencesManager;

    TextView teacherName, editMyProfile, noClassLabel;
    ImageView teacherProfilePic;
    LinearLayout profilePictureLayout;

    LinearLayout profileLayout, attendanceRecordsLayout, attendanceLayout, timetableLayout, enterClassResultLayout, personalPerformanceLayout, studentPerformanceLayout, eventsLayout, newslettersLayout,
            settingsLayout, switchAccountLayout, logoutLayout;
    TextView profile, attendanceRecords, attendance, timetable, enterClassResult, personalPerformance, studentPerformance, events, newsletters, settings, switchAccount, logout;
    TextView eventsBadge, newslettersBadge;
    ImageView profileMarker, attendanceRecordsMarker, attendanceMarker, timetableMarker, enterClassResultMarker, personalPerformanceMarker, studentPerformanceMarker, eventsMarker, newslettersMarker,
            settingsMarker, switchAccountMarker, logoutMarker;

    ArrayList<String> classesFirebase = new ArrayList<>();
    ArrayList<String> childrenFirebase = new ArrayList<>();
    private static ArrayList<Student> myChildren = new ArrayList<>();
    private static ArrayList<Class> myClasses = new ArrayList<>();
    int classesCounter = 0;
    int childrenCounter = 0;

    String featureUseKey = "";
    String featureName = "More Teacher";
    long sessionStartTime = 0;
    String sessionDurationInSeconds = "0";

    public MoreTeacherFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_more_teacher, container, false);
        context = getContext();
        sharedPreferencesManager = new SharedPreferencesManager(getContext());

        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference();
        mFirebaseUser = mAuth.getCurrentUser();

        teacherName = (TextView) view.findViewById(R.id.myprofilename);
//        editMyProfile = (TextView) view.findViewById(R.id.editmyprofile);
        noClassLabel = (TextView) view.findViewById(R.id.noclasslabel);
        teacherProfilePic = (ImageView) view.findViewById(R.id.myprofileimage);
        profilePictureLayout = (LinearLayout) view.findViewById(R.id.profilepicturelayout);

        profileLayout = (LinearLayout) view.findViewById(R.id.profileLayout);
        attendanceLayout = (LinearLayout) view.findViewById(R.id.attendanceLayout);
        attendanceRecordsLayout = (LinearLayout) view.findViewById(R.id.attendancerecordsLayout);
        timetableLayout = (LinearLayout) view.findViewById(R.id.timetableLayout);
        enterClassResultLayout = (LinearLayout) view.findViewById(R.id.enterclassresultLayout);
        personalPerformanceLayout = (LinearLayout) view.findViewById(R.id.personalperformanceLayout);
        studentPerformanceLayout = (LinearLayout) view.findViewById(R.id.studentperformanceLayout);
        eventsLayout = (LinearLayout) view.findViewById(R.id.eventsLayout);
        newslettersLayout = (LinearLayout) view.findViewById(R.id.newslettersLayout);
        settingsLayout = (LinearLayout) view.findViewById(R.id.settingsLayout);
        switchAccountLayout = (LinearLayout) view.findViewById(R.id.switchaccountLayout);
        logoutLayout = (LinearLayout) view.findViewById(R.id.logoutLayout);

        profile = (TextView) view.findViewById(R.id.profile);
        attendance = (TextView) view.findViewById(R.id.attendance);
        attendanceRecords = (TextView) view.findViewById(R.id.attendancerecords);
        timetable = (TextView) view.findViewById(R.id.timetable);
        enterClassResult = (TextView) view.findViewById(R.id.enterclassresult);
        personalPerformance = (TextView) view.findViewById(R.id.personalperformance);
        studentPerformance = (TextView) view.findViewById(R.id.studentperformance);
        events = (TextView) view.findViewById(R.id.events);
        newsletters = (TextView) view.findViewById(R.id.newsletters);
        settings = (TextView) view.findViewById(R.id.settings);
        switchAccount = (TextView) view.findViewById(R.id.switchaccount);
        logout = (TextView) view.findViewById(R.id.logout);

        eventsBadge = (TextView) view.findViewById(R.id.eventsbadge);
        newslettersBadge = (TextView) view.findViewById(R.id.newslettersbadge);

        profileMarker = (ImageView) view.findViewById(R.id.profilemarker);
        attendanceMarker = (ImageView) view.findViewById(R.id.attendancemarker);
        attendanceRecordsMarker = (ImageView) view.findViewById(R.id.attendancerecordsmarker);
        timetableMarker = (ImageView) view.findViewById(R.id.timetablemarker);
        enterClassResultMarker = (ImageView) view.findViewById(R.id.enterclassresultmarker);
        personalPerformanceMarker = (ImageView) view.findViewById(R.id.personalperformancemarker);
        studentPerformanceMarker = (ImageView) view.findViewById(R.id.studentperformancemarker);
        eventsMarker = (ImageView) view.findViewById(R.id.eventsmarker);
        newslettersMarker = (ImageView) view.findViewById(R.id.newslettersmarker);
        settingsMarker = (ImageView) view.findViewById(R.id.settingsmarker);
        switchAccountMarker = (ImageView) view.findViewById(R.id.switchaccountmarker);
        logoutMarker = (ImageView) view.findViewById(R.id.logoutmarker);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(mLayoutManager);

        moreTeachersModelList = new ArrayList<>();
        moreHeader = new MoreTeacherHeaderModel("", "");
        loadDataFromSharedPreferences();
        mAdapter = new MoreTeacherAdapter(moreTeachersModelList, getContext(), this);
        loadDataFromFirebase();
        recyclerView.setAdapter(mAdapter);

        return view;
    }

    private void loadDataFromFirebase() {
        mDatabaseReference = mFirebaseDatabase.getReference("Teacher").child(mAuth.getCurrentUser().getUid());
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Teacher teacher = dataSnapshot.getValue(Teacher.class);
                    sharedPreferencesManager.setMyFirstName(teacher.getFirstName());
                    sharedPreferencesManager.setMyLastName(teacher.getLastName());
                    sharedPreferencesManager.setMyPicURL(teacher.getProfilePicURL());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        classesCounter = 0;
        myClasses.clear();
        mDatabaseReference = mFirebaseDatabase.getReference("Teacher Class").child(mAuth.getCurrentUser().getUid());
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    final int childrenCount = (int) dataSnapshot.getChildrenCount();
                    myClasses.clear();
                    for (DataSnapshot postSnapShot: dataSnapshot.getChildren()){
                        final String classKey = postSnapShot.getKey();

                        mDatabaseReference = mFirebaseDatabase.getReference("Class").child(classKey);
                        mDatabaseReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                classesCounter++;
                                if (dataSnapshot.exists()){
                                    Class classInstance = dataSnapshot.getValue(Class.class);
                                    classInstance.setID(dataSnapshot.getKey());
                                    myClasses.add(classInstance);
                                }

                                if (classesCounter == childrenCount) {
                                    sharedPreferencesManager.deleteMyClasses();
                                    Gson gson = new Gson();
                                    String json = gson.toJson(myClasses);
                                    sharedPreferencesManager.setMyClasses(json);
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });
                    }
                } else {
                    sharedPreferencesManager.deleteMyClasses();
                    sharedPreferencesManager.deleteActiveClass();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        childrenCounter = 0;
        myChildren.clear();
        mDatabaseReference = mFirebaseDatabase.getReference("Parents Students").child(mAuth.getCurrentUser().getUid());
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    final int childrenCount = (int) dataSnapshot.getChildrenCount();
                    myChildren.clear();
                    for (DataSnapshot postSnapShot: dataSnapshot.getChildren()){
                        final String childKey = postSnapShot.getKey();

                        mDatabaseReference = mFirebaseDatabase.getReference("Student").child(childKey);
                        mDatabaseReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                childrenCounter++;
                                if (dataSnapshot.exists()){
                                    Student childInstance = dataSnapshot.getValue(Student.class);
                                    childInstance.setStudentID(dataSnapshot.getKey());
                                    myChildren.add(childInstance);
                                }

                                if (childrenCounter == childrenCount) {
                                    sharedPreferencesManager.deleteMyChildren();
                                    Gson gson = new Gson();
                                    String json = gson.toJson(myChildren);
                                    sharedPreferencesManager.setMyChildren(json);
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });
                    }
                } else {
                    sharedPreferencesManager.deleteMyChildren();
                    sharedPreferencesManager.deleteActiveKid();
                }


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void loadDataFromSharedPreferences() {
        Gson gson = new Gson();
        moreTeachersModelList = new ArrayList<>();
        String myClassesJSON = sharedPreferencesManager.getMyClasses();
        Type type = new TypeToken<ArrayList<Class>>() {}.getType();
        moreTeachersModelList = gson.fromJson(myClassesJSON, type);

        if (moreTeachersModelList == null) {
            moreTeachersModelList = new ArrayList<>();
        }

        loadHeader();
        loadFooter();
    }

    public void loadHeader() {
        teacherName.setText(sharedPreferencesManager.getMyFirstName() + " " + sharedPreferencesManager.getMyLastName());
        profilePictureLayout.setClipToOutline(true);

        if (moreTeachersModelList.size() <= 0){
            noClassLabel.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            noClassLabel.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }

        Glide.with(context)
                .load(sharedPreferencesManager.getMyPicURL())
                .centerCrop()
                .placeholder(R.drawable.profileimageplaceholder)
                .error(R.drawable.profileimageplaceholder)
                .bitmapTransform(new CropCircleTransformation(context))
                .into(teacherProfilePic);

//        editMyProfile.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent I = new Intent(context, EditTeacherProfileActivity.class);
//                Bundle b = new Bundle();
//                b.putString("id", mAuth.getCurrentUser().getUid());
//                context.startActivity(I);
//            }
//        });

        teacherName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, TeacherProfileOneActivity.class);
                Bundle b = new Bundle();
                b.putString("ID", mAuth.getCurrentUser().getUid());
                I.putExtras(b);
                context.startActivity(I);
            }
        });

        teacherProfilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, TeacherProfileOneActivity.class);
                Bundle b = new Bundle();
                b.putString("ID", mAuth.getCurrentUser().getUid());
                I.putExtras(b);
                context.startActivity(I);
            }
        });
    }

    public void loadFooter() {
        loadUpBadgesAndMarkers();

        String prf = "Class Profile";
        String att = "Take Class Attendance";
        String atr = "Class Attendance Records";
        String ecr = "Enter Class Results";
        String ttb = "My TimeTable";
        String mpef = "My Performance Analytics";
        String cpef = "Class Academic Records";
        String evt = "Events";
        String nws = "Newsletters";
        String set = "Settings";
        String swt = "Switch to Parenting";
        String lgt = "Logout";

        String activeClass = null;
        activeClass = sharedPreferencesManager.getActiveClass();

        if (activeClass == null) {
            Gson gson = new Gson();
            ArrayList<Class> myClasses = new ArrayList<>();
            String myClassesJSON = sharedPreferencesManager.getMyClasses();
            Type type = new TypeToken<ArrayList<Class>>() {}.getType();
            myClasses = gson.fromJson(myClassesJSON, type);

            if (myClasses != null) {
                gson = new Gson();
                activeClass = gson.toJson(myClasses.get(0));
                sharedPreferencesManager.setActiveClass(activeClass);
            }
        }

        Gson gson = new Gson();
        Type type = new TypeToken<Class>() {}.getType();
        Class activeClassModel = gson.fromJson(activeClass, type);

        if (activeClass != null){
            String className = activeClassModel.getClassName();
            prf = className + "'s Profile";
            att = "Take " + className + "'s Attendance";
            atr = "View " + className + "'s Attendance Records";
            ecr = "Enter Results for " + className ;
            cpef = "View " + className + "'s Academic Records";
        }

        profile.setText(prf);
        attendance.setText(att);
        attendanceRecords.setText(atr);
        timetable.setText(ttb);
        enterClassResult.setText(ecr);
        personalPerformance.setText(mpef);
        studentPerformance.setText(cpef);
        events.setText(evt);
        newsletters.setText(nws);
        settings.setText(set);
        switchAccount.setText(swt);
        logout.setText(lgt);

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                    Intent I = new Intent(context, TeacherAttendanceActivity.class);
                Intent I = new Intent(context, ClassProfileActivity.class);
                context.startActivity(I);
            }
        });
        attendanceLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                    Intent I = new Intent(context, TeacherAttendanceActivity.class);
                Intent I = new Intent(context, TeacherTakeAttendanceActivity.class);
                context.startActivity(I);
            }
        });
        attendanceRecordsLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, TeacherAttendanceActivity.class);
                context.startActivity(I);
            }
        });
        timetableLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, TeacherTimetableActivity.class);
                context.startActivity(I);
            }
        });
        enterClassResultLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, EnterResultsActivity.class);
                context.startActivity(I);
            }
        });
        personalPerformanceLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, TeacherPerformanceRowActivity.class);
                context.startActivity(I);
            }
        });
        studentPerformanceLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, StudentAcademicHistoryActivity.class);
                context.startActivity(I);
            }
        });
        eventsLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, EventsRowActivity.class);
                context.startActivity(I);
            }
        });
        newslettersLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, NewsletterRowActivity.class);
                context.startActivity(I);
            }
        });
        settingsLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, SettingsActivityTeacher.class);
                context.startActivity(I);
            }
        });
        switchAccountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(context, SwitchActivityTeacherParent.class);
                context.startActivity(I);
                ((Activity)context).finish();
//                    Toast.makeText(context, "switchAccountLayout clicked", Toast.LENGTH_SHORT).show();
//                    loginParent("Parent");
            }
        });
        logoutLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO: Test how logging out without internet works

                LogoutProtocol.logout(context, "You're being logged out");
//                sharedPreferencesManager.deleteActiveAccount();
//                sharedPreferencesManager.deleteMyUserID();
//                sharedPreferencesManager.deleteMyFirstName();
//                sharedPreferencesManager.deleteMyLastName();
//                sharedPreferencesManager.deleteMyPicURL();
//                sharedPreferencesManager.deleteActiveKid();
//                sharedPreferencesManager.deleteActiveClass();
//                sharedPreferencesManager.deleteMyClasses();
//                sharedPreferencesManager.deleteMyChildren();
//                Intent I = new Intent(context, IntroSlider.class);
//                context.startActivity(I);
//                mAuth.signOut();
//                ((Activity)context).finish();
            }
        });

    }

    private void loadUpBadgesAndMarkers() {
        mDatabaseReference = mFirebaseDatabase.getReference().child("Notification Badges").child("Parents").child(mFirebaseUser.getUid()).child("Events").child("status");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    boolean status = dataSnapshot.getValue(boolean.class);
                    if (status) {
                        eventsBadge.setVisibility(View.VISIBLE);
                    } else {
                        eventsBadge.setVisibility(View.GONE);
                    }
                } else {
                    eventsBadge.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mDatabaseReference = mFirebaseDatabase.getReference().child("Notification Badges").child("Parents").child(mFirebaseUser.getUid()).child("Newsletter").child("status");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    boolean status = dataSnapshot.getValue(boolean.class);
                    if (status) {
                        newslettersBadge.setVisibility(View.VISIBLE);
                    } else {
                        newslettersBadge.setVisibility(View.GONE);
                    }
                } else {
                    newslettersBadge.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onResume() {
        loadDataFromSharedPreferences();
        loadDataFromFirebase();
        UpdateDataFromFirebase.populateEssentials(getContext());
        super.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();

        if (sharedPreferencesManager.getActiveAccount().equals("Parent")) {
            featureUseKey = Analytics.featureAnalytics("Parent", mFirebaseUser.getUid(), featureName);
        } else {
            featureUseKey = Analytics.featureAnalytics("Teacher", mFirebaseUser.getUid(), featureName);
        }
        sessionStartTime = System.currentTimeMillis();
    }

    @Override
    public void onStop() {
        super.onStop();

        sessionDurationInSeconds = String.valueOf((System.currentTimeMillis() - sessionStartTime) / 1000);
        String day = Date.getDay();
        String month = Date.getMonth();
        String year = Date.getYear();
        String day_month_year = day + "_" + month + "_" + year;
        String month_year = month + "_" + year;

        HashMap<String, Object> featureUseUpdateMap = new HashMap<>();
        String mFirebaseUserID = mFirebaseUser.getUid();

        featureUseUpdateMap.put("Analytics/Feature Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Daily Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + day_month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Monthly Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Yearly Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);

        featureUseUpdateMap.put("Analytics/Feature Use Analytics/" + featureName + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Daily Use Analytics/" + featureName + "/" + day_month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Monthly Use Analytics/" + featureName + "/" + month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Yearly Use Analytics/" + featureName + "/" + year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);

        DatabaseReference featureUseUpdateRef = FirebaseDatabase.getInstance().getReference();
        featureUseUpdateRef.updateChildren(featureUseUpdateMap);
    }
}
