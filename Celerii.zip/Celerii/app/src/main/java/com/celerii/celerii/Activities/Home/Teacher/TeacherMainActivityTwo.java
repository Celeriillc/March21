package com.celerii.celerii.Activities.Home.Teacher;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.aurelhubert.ahbottomnavigation.notification.AHNotification;
import com.celerii.celerii.Activities.Inbox.InboxFragment;
import com.celerii.celerii.Activities.Intro.IntroSlider;
import com.celerii.celerii.Activities.Search.Teacher.SearchActivity;
import com.celerii.celerii.R;
import com.celerii.celerii.helperClasses.Analytics;
import com.celerii.celerii.helperClasses.ApplicationLauncherSharedPreferences;
import com.celerii.celerii.helperClasses.CheckLoginState;
import com.celerii.celerii.helperClasses.CustomToast;
import com.celerii.celerii.helperClasses.ServerDeviceTimeDifference;
import com.celerii.celerii.helperClasses.SharedPreferencesManager;
import com.celerii.celerii.helperClasses.UpdateDataFromFirebase;
import com.celerii.celerii.models.NotificationBadgeModel;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.HashMap;
import java.util.Map;

public class TeacherMainActivityTwo extends AppCompatActivity {
    Context context = this;

    SharedPreferencesManager sharedPreferencesManager;
    ApplicationLauncherSharedPreferences applicationLauncherSharedPreferences;
    FirebaseAuth auth;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mDatabaseReference;
    FirebaseUser mFirebaseUser;
    AHBottomNavigation bottomNavigation;
    FragmentTransaction mFragmentTransaction;
    Fragment frag1, frag2, frag3, frag4, frag5, active;
    Toolbar toolbar;
    long sessionStartTime = 0;
    String sessionDurationInSeconds = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_main_two);

        sharedPreferencesManager = new SharedPreferencesManager(this);
        applicationLauncherSharedPreferences = new ApplicationLauncherSharedPreferences(this);
        bottomNavigation = (AHBottomNavigation) findViewById(R.id.bottom_navigation);
        toolbar = (Toolbar) findViewById(R.id.hometoolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setElevation(0);

        auth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference();
        mFirebaseUser = auth.getCurrentUser();
        if (mFirebaseUser == null){
            sharedPreferencesManager.clear();
            Intent I = new Intent(TeacherMainActivityTwo.this, IntroSlider.class);
            applicationLauncherSharedPreferences.setLauncherActivity("IntroSlider");
            startActivity(I);
            finish();
            return;
        }

        // Create items
        AHBottomNavigationItem item1 = new AHBottomNavigationItem("Class Home", R.drawable.ic_home_white_24dp, R.color.colorPrimary);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem("Class Feed", R.drawable.ic_newspaper, R.color.colorPrimary);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem("Inbox", R.drawable.ic_chat_black_24dp, R.color.colorPrimary);
        AHBottomNavigationItem item4 = new AHBottomNavigationItem("Notifications", R.drawable.ic_notifications_black_24dp, R.color.colorPrimary);
        AHBottomNavigationItem item5 = new AHBottomNavigationItem("More", R.drawable.ic_more_black_24dp, R.color.colorPrimary);

        // Add items
        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.addItem(item4);
        bottomNavigation.addItem(item5);

        bottomNavigation.setAccentColor(ContextCompat.getColor(this, R.color.colorPrimaryPurple));
        bottomNavigation.setInactiveColor(ContextCompat.getColor(this, R.color.colorDeepGray));
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.ALWAYS_SHOW);
        bottomNavigation.setCurrentItem(0);
        loadBadgesFromFirebase();
        initFCM();
        bottomNavigation.setUseElevation(false);

        mFragmentTransaction = getSupportFragmentManager().beginTransaction();
        frag1 = new TeacherHomeClass();
        frag2 = new TeacherHomeClassFeed();
        frag3 = new InboxFragment();
        frag4 = new TeacherHomeNotification();
        frag5 = new MoreTeacherFragment();

        bottomNavigation.setNotification("", 0);
//        mFragmentTransaction.replace(R.id.frame_fragmentholder, frag1);
//        mFragmentTransaction.commit();

        mFragmentTransaction.add(R.id.frame_fragmentholder, frag5).hide(frag5);
        mFragmentTransaction.add(R.id.frame_fragmentholder, frag4).hide(frag4);
        mFragmentTransaction.add(R.id.frame_fragmentholder, frag3).hide(frag3);
        mFragmentTransaction.add(R.id.frame_fragmentholder, frag2).hide(frag2);
        mFragmentTransaction.add(R.id.frame_fragmentholder, frag1);
        mFragmentTransaction.commit();
        active = frag1;

        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                switch (position) {
                    case 0:
                        bottomNavigation.setNotification("", 0);
//                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag1).commit();
                        getSupportFragmentManager().beginTransaction().hide(active).show(frag1).commit();
                        active = frag1;
                        return true;
                    case 1:
                        bottomNavigation.setNotification("", 1);
//                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag2).commit();
                        getSupportFragmentManager().beginTransaction().hide(active).show(frag2).commit();
                        active = frag2;
                        return true;
                    case 2:
                        DatabaseReference bottomNavBadgeRef = mFirebaseDatabase.getReference();
                        Map<String, Object> bottomNavBadgeMap = new HashMap<String, Object>();
                        NotificationBadgeModel notificationBadgeModel = new NotificationBadgeModel(false, 0);
                        bottomNavBadgeMap.put("Notification Badges/General/" + mFirebaseUser.getUid() + "/Inbox", notificationBadgeModel);
                        bottomNavBadgeRef.updateChildren(bottomNavBadgeMap);
                        bottomNavigation.setNotification("", 2);
//                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag3).commit();
                        getSupportFragmentManager().beginTransaction().hide(active).show(frag3).commit();
                        active = frag3;
                        return true;
                    case 3:
                        bottomNavBadgeRef = mFirebaseDatabase.getReference();
                        bottomNavBadgeMap = new HashMap<String, Object>();
                        notificationBadgeModel = new NotificationBadgeModel(false, 0);
                        bottomNavBadgeMap.put("Notification Badges/Teachers/" + mFirebaseUser.getUid() + "/Notifications", notificationBadgeModel);
                        bottomNavBadgeRef.updateChildren(bottomNavBadgeMap);
                        bottomNavigation.setNotification("", 3);
//                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag4).commit();
                        getSupportFragmentManager().beginTransaction().hide(active).show(frag4).commit();
                        active = frag4;
                        return true;
                    case 4:
                        bottomNavBadgeRef = mFirebaseDatabase.getReference();
                        bottomNavBadgeMap = new HashMap<String, Object>();
                        notificationBadgeModel = new NotificationBadgeModel(false, 0);
                        bottomNavBadgeMap.put("Notification Badges/Teachers/" + mFirebaseUser.getUid() + "/More", notificationBadgeModel);
                        bottomNavBadgeRef.updateChildren(bottomNavBadgeMap);
                        bottomNavigation.setNotification("", 4);
//                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag5).commit();
                        getSupportFragmentManager().beginTransaction().hide(active).show(frag5).commit();
                        active = frag5;
                        return true;
                }
                return false;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_search){
            startActivity(new Intent(TeacherMainActivityTwo.this, SearchActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadBadgesFromFirebase(){
        mDatabaseReference = mFirebaseDatabase.getReference().child("Notification Badges").child("General").child(mFirebaseUser.getUid()).child("Inbox");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    NotificationBadgeModel notificationBadgeModel = dataSnapshot.getValue(NotificationBadgeModel.class);
                    if (notificationBadgeModel.getStatus()){
                        if (sharedPreferencesManager.getActiveAccount().equals("Teacher")) {
                            CustomToast.blueBackgroundToast(getBaseContext(), "New message in your inbox.");
                        }
                        AHNotification notification = new AHNotification.Builder()
                                .setText(" ")
                                .setBackgroundColor(ContextCompat.getColor(context, R.color.colorAccent))
                                .setTextColor(ContextCompat.getColor(context, R.color.white))
                                .build();
                        bottomNavigation.setNotification(notification, 2);
                    } else {
                        bottomNavigation.setNotification("", 2);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mDatabaseReference = mFirebaseDatabase.getReference().child("Notification Badges").child("Teachers").child(mFirebaseUser.getUid()).child("Notifications");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    NotificationBadgeModel notificationBadgeModel = dataSnapshot.getValue(NotificationBadgeModel.class);
                    if (notificationBadgeModel.getStatus()){
                        if (sharedPreferencesManager.getActiveAccount().equals("Teacher")) {
                            CustomToast.blueBackgroundToast(getBaseContext(), "New notification.");
                        }
                        AHNotification notification = new AHNotification.Builder()
                                .setText(" ")
                                .setBackgroundColor(ContextCompat.getColor(context, R.color.colorAccent))
                                .setTextColor(ContextCompat.getColor(context, R.color.white))
                                .build();
                        bottomNavigation.setNotification(notification, 3);
                    } else {
                        bottomNavigation.setNotification("", 3);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mDatabaseReference = mFirebaseDatabase.getReference().child("Notification Badges").child("Teachers").child(mFirebaseUser.getUid()).child("More");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    NotificationBadgeModel notificationBadgeModel = dataSnapshot.getValue(NotificationBadgeModel.class);
                    if (notificationBadgeModel.getStatus()){
                        AHNotification notification = new AHNotification.Builder()
                                .setText(" ")
                                .setBackgroundColor(ContextCompat.getColor(context, R.color.colorAccent))
                                .setTextColor(ContextCompat.getColor(context, R.color.white))
                                .build();
                        bottomNavigation.setNotification(notification, 4);
                    } else {
                        bottomNavigation.setNotification("", 4);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Analytics.loginAnalytics(context,  mFirebaseUser.getUid(), "Teacher");
        sessionStartTime = System.currentTimeMillis();
    }

    @Override
    protected void onStop () {
        super.onStop();
        try {
            CustomToast.cancelToast();
        } catch (Exception e) {

        }

        sessionDurationInSeconds = String.valueOf((System.currentTimeMillis() - sessionStartTime) / 1000);
        String currentSessionLoginKey = sharedPreferencesManager.getCurrentLoginSessionKey();
        String day_month_year = sharedPreferencesManager.getCurrentLoginSessionDayMonthYear();
        String month_year = sharedPreferencesManager.getCurrentLoginSessionMonthYear();
        String year = sharedPreferencesManager.getCurrentLoginSessionYear();
        HashMap<String, Object> loginUpdateMap = new HashMap<>();
        String mFirebaseUserID = mFirebaseUser.getUid();

        loginUpdateMap.put("Analytics/User Login History/" + mFirebaseUserID + "/" + currentSessionLoginKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        loginUpdateMap.put("Analytics/User Daily Login History/" + mFirebaseUserID + "/" + day_month_year + "/" + currentSessionLoginKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        loginUpdateMap.put("Analytics/User Monthly Login History/" + mFirebaseUserID + "/" + month_year + "/" + currentSessionLoginKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        loginUpdateMap.put("Analytics/User Yearly Login History/" + mFirebaseUserID + "/" + year + "/" + currentSessionLoginKey + "/sessionDurationInSeconds", sessionDurationInSeconds);

        loginUpdateMap.put("Analytics/Login History/" + currentSessionLoginKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        loginUpdateMap.put("Analytics/Daily Login History/" + day_month_year + "/" + currentSessionLoginKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        loginUpdateMap.put("Analytics/Monthly Login History/" + month_year + "/" + currentSessionLoginKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        loginUpdateMap.put("Analytics/Yearly Login History/" + year + "/" + currentSessionLoginKey + "/sessionDurationInSeconds", sessionDurationInSeconds);

        DatabaseReference loginUpdateRef = FirebaseDatabase.getInstance().getReference();
        loginUpdateRef.updateChildren(loginUpdateMap);
    }

    @Override
    protected void onResume() {
        super.onResume();
        int currentItem = bottomNavigation.getCurrentItem();
        if (currentItem == 0){
//            getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag1).commit();
            getSupportFragmentManager().beginTransaction().hide(active).show(frag1).commit();
            active = frag1;
        } else if (currentItem == 1){
//            getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag2).commit();
            getSupportFragmentManager().beginTransaction().hide(active).show(frag2).commit();
            active = frag2;
        } else if (currentItem == 2){
//            getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag3).commit();
            getSupportFragmentManager().beginTransaction().hide(active).show(frag3).commit();
            active = frag3;
        } else if (currentItem == 3){
//            getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag4).commit();
            getSupportFragmentManager().beginTransaction().hide(active).show(frag4).commit();
            active = frag4;
        } else if (currentItem == 4){
//            getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragmentholder, frag5).commit();
            getSupportFragmentManager().beginTransaction().hide(active).show(frag5).commit();
            active = frag5;
        }
        UpdateDataFromFirebase.populateEssentials(this);
        ServerDeviceTimeDifference.getDeviceServerTimeDifference(this);
        CheckLoginState.isLoggedIn(this);
    }

    private void initFCM(){
        String token = FirebaseInstanceId.getInstance().getToken();
        sendRegistrationToServer(token);
    }

    private void sendRegistrationToServer(String token) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        String deviceID = FirebaseInstanceId.getInstance().getId();
        reference.child("UserRoles").child(mFirebaseUser.getUid()).child("Tokens").child(deviceID).setValue(token);
    }
}
