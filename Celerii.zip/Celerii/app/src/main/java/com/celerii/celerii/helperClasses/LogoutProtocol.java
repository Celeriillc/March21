package com.celerii.celerii.helperClasses;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.celerii.celerii.Activities.Intro.IntroSlider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LogoutProtocol {
    public static void logout(Context context, String signOutMessage) {
        SharedPreferencesManager sharedPreferencesManager = new SharedPreferencesManager(context);
        ApplicationLauncherSharedPreferences applicationLauncherSharedPreferences = new ApplicationLauncherSharedPreferences(context);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        sharedPreferencesManager.clear();
        applicationLauncherSharedPreferences.setLauncherActivity("IntroSlider");
        Intent I = new Intent(context, IntroSlider.class);
        context.startActivity(I);
        auth.signOut();
        ((Activity)context).finishAffinity();
        CustomToast.blueBackgroundToast(context, signOutMessage);
    }
}
