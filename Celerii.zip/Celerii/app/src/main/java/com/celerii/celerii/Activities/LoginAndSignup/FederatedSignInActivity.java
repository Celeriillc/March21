package com.celerii.celerii.Activities.LoginAndSignup;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.celerii.celerii.Activities.Home.Parent.ParentMainActivityTwo;
import com.celerii.celerii.Activities.Home.Teacher.TeacherMainActivityTwo;
import com.celerii.celerii.R;
import com.celerii.celerii.helperClasses.ApplicationLauncherSharedPreferences;
import com.celerii.celerii.helperClasses.CustomProgressDialogOne;
import com.celerii.celerii.helperClasses.SharedPreferencesManager;
import com.celerii.celerii.helperClasses.UpdateDataFromFirebaseForLogin;
import com.celerii.celerii.models.Class;
import com.celerii.celerii.models.Parent;
import com.celerii.celerii.models.Student;
import com.celerii.celerii.models.Teacher;
import com.celerii.celerii.models.User;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class FederatedSignInActivity extends AppCompatActivity {
    SharedPreferencesManager sharedPreferencesManager;
    ApplicationLauncherSharedPreferences applicationLauncherSharedPreferences;
    Context context = this;

    FirebaseAuth mAuth;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mDatabaseReference;
    FirebaseUser mFirebaseUser;

    private Toolbar mToolbar;
    Button google;

    private GoogleApiClient mGoogleApiClient;
    private static final int RC_SIGN_IN_GOOGLE = 9001;
    private static final String TAG = "FederatedAuthActivity";

    CustomProgressDialogOne progressDialog;

    ArrayList<String> childrenFirebase = new ArrayList<>();
    ArrayList<String> classesFirebase = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_federated_sign_in);

        sharedPreferencesManager = new SharedPreferencesManager(this);
        applicationLauncherSharedPreferences = new ApplicationLauncherSharedPreferences(this);

        mToolbar = (Toolbar) findViewById(R.id.introtoolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Federated Authentication");
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference();
        progressDialog = new CustomProgressDialogOne(FederatedSignInActivity.this);

        google = (Button) findViewById(R.id.google);

        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(FederatedSignInActivity.this)
                .enableAutoManage(FederatedSignInActivity.this , new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

                    }
                } /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, googleSignInOptions)
                .build();

        google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                googleUserSignInMethod();
            }
        });
    }

    public void googleUserSignInMethod(){
        Intent AuthIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(AuthIntent, RC_SIGN_IN_GOOGLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN_GOOGLE){
            GoogleSignInResult googleSignInResult = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (googleSignInResult.isSuccess()){
                GoogleSignInAccount googleSignInAccount = googleSignInResult.getSignInAccount();
                FirebaseUserAuthGoogle(googleSignInAccount);
            } else {
                showDialogWithMessage("Your Google sign in attempt could not be completed, please try again, possibly with an email and password.");
            }
        }
    }

    public void FirebaseUserAuthGoogle(GoogleSignInAccount googleSignInAccount) {
        progressDialog.show();
        AuthCredential authCredential = GoogleAuthProvider.getCredential(googleSignInAccount.getIdToken(), null);
        mAuth.signInWithCredential(authCredential).addOnCompleteListener(FederatedSignInActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> AuthResultTask) {
                if (AuthResultTask.isSuccessful()){
                    mFirebaseUser = mAuth.getCurrentUser();
                    final String userID = mFirebaseUser.getUid();
                    mDatabaseReference = mFirebaseDatabase.getReference().child("UserRoles").child(userID);
                    mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                sharedPreferencesManager.clear();
                                User user = dataSnapshot.getValue(User.class);
                                String activeAccount = user.getRole();
                                UpdateDataFromFirebaseForLogin.populateEssentials(context, activeAccount, progressDialog);
//                                login(activeAccount);
                            } else {
                                sharedPreferencesManager.clear();
                                Map<String, Object> updateMap = new HashMap<String, Object>();
                                final String userName = mFirebaseUser.getDisplayName();
                                String userEmail = mFirebaseUser.getEmail();
                                String refactoredEmail = userEmail.replace(".", "_fullStop_");
                                Parent parent = new Parent(userName, "", userName.toLowerCase(), "", userEmail);
                                Teacher teacher = new Teacher(userName, "", userName.toLowerCase(), "", userEmail);
                                final User user = new User(userEmail, "Parent");
                                updateMap.put("Parent/" + userID, parent);
                                updateMap.put("Teacher/" + userID, teacher);
                                updateMap.put("UserRoles/" + userID, user);
                                updateMap.put("Email/" + refactoredEmail, "true");

                                mDatabaseReference = mFirebaseDatabase.getReference();
                                mDatabaseReference.updateChildren(updateMap, new DatabaseReference.CompletionListener() {
                                    @Override
                                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                                        saveToSharedPreferencesAndProceed("Parent", userID, userName, "");
                                    }
                                });
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                } else {
                    progressDialog.dismiss();
                    showDialogWithMessage("Your Google sign in attempt could not be completed, please try again, possibly with an email and password.");
                }
            }
        });
    }

    void showDialogWithMessage (String messageString) {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.custom_unary_message_dialog);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        TextView message = (TextView) dialog.findViewById(R.id.dialogmessage);
        TextView OK = (TextView) dialog.findViewById(R.id.optionone);
        dialog.show();

        message.setText(messageString);

        OK.setText("OK");

        OK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    void saveToSharedPreferencesAndProceed(String accountType, String activeUserID, String firstName, String lastName) {
        sharedPreferencesManager.setActiveAccount(accountType);
        sharedPreferencesManager.setMyUserID(activeUserID);
        sharedPreferencesManager.setMyFirstName(firstName);
        sharedPreferencesManager.setMyLastName(lastName);
        applicationLauncherSharedPreferences.setLauncherActivity("FederatedSignInAccountType");
        progressDialog.dismiss();
        finishAffinity();
        Intent I = new Intent(FederatedSignInActivity.this, FederatedSignInAccountTypeActivity.class);
        startActivity(I);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home)
        {
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
