package com.celerii.celerii.Activities.Home.Parent;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.celerii.celerii.R;
import com.celerii.celerii.adapters.ClassNotificationAdapter;
import com.celerii.celerii.helperClasses.Analytics;
import com.celerii.celerii.helperClasses.CheckNetworkConnectivity;
import com.celerii.celerii.helperClasses.CustomToast;
import com.celerii.celerii.helperClasses.Date;
import com.celerii.celerii.helperClasses.SharedPreferencesManager;
import com.celerii.celerii.helperClasses.UpdateDataFromFirebase;
import com.celerii.celerii.models.NotificationBadgeModel;
import com.celerii.celerii.models.NotificationModel;
import com.celerii.celerii.models.Parent;
import com.celerii.celerii.models.School;
import com.celerii.celerii.models.Teacher;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class ParentHomeNotification extends Fragment {

    Context context;
    SharedPreferencesManager sharedPreferencesManager;

    FirebaseAuth auth;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mDatabaseReference;
    FirebaseUser mFirebaseUser;

    SwipeRefreshLayout mySwipeRefreshLayout;
    RelativeLayout errorLayout, progressLayout;
    TextView errorLayoutText;

    private ArrayList<NotificationModel> notificationModelList;
    public RecyclerView recyclerView;
    public ClassNotificationAdapter mAdapter;
    LinearLayoutManager mLayoutManager;

    String activeAccount = "";
    int counter;

    String featureUseKey = "";
    String featureName = "Parent Notification";
    long sessionStartTime = 0;
    String sessionDurationInSeconds = "0";

    public ParentHomeNotification() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_parent_home_notification, container, false);

        context = getContext();
        sharedPreferencesManager = new SharedPreferencesManager(getContext());
        activeAccount = sharedPreferencesManager.getActiveAccount();

        auth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference();
        mFirebaseUser = auth.getCurrentUser();

        mySwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swiperefresh);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        errorLayout = (RelativeLayout) view.findViewById(R.id.errorlayout);
        errorLayoutText = (TextView) errorLayout.findViewById(R.id.errorlayouttext);
        progressLayout = (RelativeLayout) view.findViewById(R.id.progresslayout);

        mLayoutManager = new LinearLayoutManager(view.getContext());
        recyclerView.setLayoutManager(mLayoutManager);

        recyclerView.setVisibility(View.GONE);
        progressLayout.setVisibility(View.VISIBLE);

        notificationModelList = new ArrayList<>();
        loadFromSharedPreferences();
        mAdapter = new ClassNotificationAdapter(notificationModelList, getContext());
        recyclerView.setAdapter(mAdapter);
        loadFromFirebase();

//        DatabaseReference childEventRef = mFirebaseDatabase.getReference("NotificationParent").child(mFirebaseUser.getUid());
//        childEventRef.addChildEventListener(new ChildEventListener() {
//            @Override
//            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
//                if (dataSnapshot.exists()) {
//                    loadFromFirebase();
//                }
//            }
//
//            @Override
//            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
//
//            }
//
//            @Override
//            public void onChildRemoved(DataSnapshot dataSnapshot) {
//
//            }
//
//            @Override
//            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
//
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//
//            }
//        });

//        mDatabaseReference = mFirebaseDatabase.getReference().child("NotificationParent").child(mFirebaseUser.getUid());
//        mDatabaseReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                if (dataSnapshot.exists()) {
//                    loadFromFirebase();
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//
//            }
//        });

        mySwipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        loadFromFirebase();
                    }
                }
        );

        return view;
    }

    private void loadFromSharedPreferences() {
        Gson gson = new Gson();
        notificationModelList = new ArrayList<>();
        String messagesJSON = sharedPreferencesManager.getParentNotification();
        Type type = new TypeToken<ArrayList<NotificationModel>>() {}.getType();
        notificationModelList = gson.fromJson(messagesJSON, type);

        if (notificationModelList == null) {
            notificationModelList = new ArrayList<>();
            mAdapter = new ClassNotificationAdapter(notificationModelList, getContext());
            recyclerView.setAdapter(mAdapter);
            recyclerView.setVisibility(View.GONE);
            progressLayout.setVisibility(View.GONE);
            errorLayout.setVisibility(View.VISIBLE);
            errorLayoutText.setText(Html.fromHtml("You don't have any notifications at this time. If you're not connected to any of your children's account, use the search button to " + "<b>" + "Search" + "</b>" + " for your children and send a request to connect to their accounts."));
        } else {
            mAdapter = new ClassNotificationAdapter(notificationModelList, getContext());
            recyclerView.setAdapter(mAdapter);
            mySwipeRefreshLayout.setRefreshing(false);
            progressLayout.setVisibility(View.GONE);
            errorLayout.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void loadFromFirebase() {
        if (!CheckNetworkConnectivity.isNetworkAvailable(getContext())) {
            mySwipeRefreshLayout.setRefreshing(false);
            progressLayout.setVisibility(View.GONE);
            errorLayout.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            CustomToast.blueBackgroundToast(context, "No Internet");
            return;
        }


        mDatabaseReference = mFirebaseDatabase.getReference().child("NotificationParent").child(mFirebaseUser.getUid());
        mDatabaseReference.orderByChild("time").limitToLast(50).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    notificationModelList.clear();
//                    mAdapter.notifyDataSetChanged();
                    counter = 0;
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                        final int childrenCount = (int) dataSnapshot.getChildrenCount();
                        final NotificationModel notificationModel = postSnapshot.getValue(NotificationModel.class);
                        notificationModel.setSortableTime(Date.convertToSortableDate(notificationModel.getTime()));

                        if (notificationModel.getFromAccountType().equals("School")) {
                            mDatabaseReference = mFirebaseDatabase.getReference().child("School").child(notificationModel.getFromID());
                            mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    counter++;
                                    if (dataSnapshot.exists()) {
                                        School school = dataSnapshot.getValue(School.class);
                                        notificationModel.setFromName(school.getSchoolName());
                                        notificationModel.setFromProfilePicture(school.getProfilePhotoUrl());
                                    } else {
                                        notificationModel.setFromName("A user");
                                    }
                                    notificationModelList.add(notificationModel);

                                    if (counter == childrenCount) {
                                        if (notificationModelList.size() > 1) {
                                            Collections.sort(notificationModelList, new Comparator<NotificationModel>() {
                                                @Override
                                                public int compare(NotificationModel o1, NotificationModel o2) {
                                                    return o1.getSortableTime().compareTo(o2.getSortableTime());
                                                }
                                            });
                                        }

                                        Collections.reverse(notificationModelList);
                                        Gson gson = new Gson();
                                        String json = gson.toJson(notificationModelList);
                                        sharedPreferencesManager.setParentNotification(json);
//                                        loadFromSharedPreferences();
                                        mAdapter.notifyDataSetChanged();
                                        mySwipeRefreshLayout.setRefreshing(false);
//                                        progressLayout.setVisibility(View.GONE);
//                                        errorLayout.setVisibility(View.GONE);
//                                        recyclerView.setVisibility(View.VISIBLE);
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });
                        }
                        else {
                            mDatabaseReference = mFirebaseDatabase.getReference().child("Teacher").child(notificationModel.getFromID());
                            mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    counter++;
                                    if (dataSnapshot.exists()) {
                                        Teacher teacher = dataSnapshot.getValue(Teacher.class);
                                        notificationModel.setFromName(teacher.getFirstName() + " " + teacher.getLastName());
                                        notificationModel.setFromProfilePicture(teacher.getProfilePicURL());
                                    } else {
                                        notificationModel.setFromName("A user");
                                    }
                                    notificationModelList.add(notificationModel);

                                    if (counter == childrenCount) {
                                        if (notificationModelList.size() > 1) {
                                            Collections.sort(notificationModelList, new Comparator<NotificationModel>() {
                                                @Override
                                                public int compare(NotificationModel o1, NotificationModel o2) {
                                                    return o1.getSortableTime().compareTo(o2.getSortableTime());
                                                }
                                            });
                                        }

                                        Collections.reverse(notificationModelList);
                                        Gson gson = new Gson();
                                        String json = gson.toJson(notificationModelList);
                                        sharedPreferencesManager.setParentNotification(json);
//                                        loadFromSharedPreferences();
                                        mAdapter.notifyDataSetChanged();
                                        mySwipeRefreshLayout.setRefreshing(false);
//                                        progressLayout.setVisibility(View.GONE);
//                                        errorLayout.setVisibility(View.GONE);
//                                        recyclerView.setVisibility(View.VISIBLE);
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });
                        }
                    }
                } else {
                    mySwipeRefreshLayout.setRefreshing(false);
                    recyclerView.setVisibility(View.GONE);
                    progressLayout.setVisibility(View.GONE);
                    errorLayout.setVisibility(View.VISIBLE);
                    errorLayoutText.setText(Html.fromHtml("You don't have any notifications at this time. If you're not connected to any of your children's account, use the search button to " + "<b>" + "Search" + "</b>" + " for your children and send a request to connect to their accounts."));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();

        if (sharedPreferencesManager.getActiveAccount().equals("Parent")) {
            featureUseKey = Analytics.featureAnalytics("Parent", mFirebaseUser.getUid(), featureName);
        } else {
            featureUseKey = Analytics.featureAnalytics("Teacher", mFirebaseUser.getUid(), featureName);
        }
        sessionStartTime = System.currentTimeMillis();
        UpdateDataFromFirebase.populateEssentials(getContext());
    }

    @Override
    public void onStop() {
        super.onStop();

        sessionDurationInSeconds = String.valueOf((System.currentTimeMillis() - sessionStartTime) / 1000);
        String day = Date.getDay();
        String month = Date.getMonth();
        String year = Date.getYear();
        String day_month_year = day + "_" + month + "_" + year;
        String month_year = month + "_" + year;

        HashMap<String, Object> featureUseUpdateMap = new HashMap<>();
        String mFirebaseUserID = mFirebaseUser.getUid();

        featureUseUpdateMap.put("Analytics/Feature Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Daily Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + day_month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Monthly Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Yearly Use Analytics User/" + mFirebaseUserID + "/" + featureName + "/" + year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);

        featureUseUpdateMap.put("Analytics/Feature Use Analytics/" + featureName + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Daily Use Analytics/" + featureName + "/" + day_month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Monthly Use Analytics/" + featureName + "/" + month_year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);
        featureUseUpdateMap.put("Analytics/Feature Yearly Use Analytics/" + featureName + "/" + year + "/" + featureUseKey + "/sessionDurationInSeconds", sessionDurationInSeconds);

        DatabaseReference featureUseUpdateRef = FirebaseDatabase.getInstance().getReference();
        featureUseUpdateRef.updateChildren(featureUseUpdateMap);
    }
}
