package com.celerii.celerii.Activities.Profiles.SchoolProfile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.celerii.celerii.R;

public class SchoolProfileNoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school_profile_note);
    }
}
